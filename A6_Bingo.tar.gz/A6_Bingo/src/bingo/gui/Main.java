/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.gui;

/**
 *
 * @author ju39gox
 */
public class Main
{
    public static void main(String[] args)
    {
        MainWindow wnd = new MainWindow();
        wnd.setVisible(true);
    }
}
