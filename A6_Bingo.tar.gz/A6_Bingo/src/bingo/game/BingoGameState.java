/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.game;

/**
 *
 * @author ju39gox
 */
public enum BingoGameState
{
    NOT_STARTED,
    RUNNING,
    FINISHED
}
