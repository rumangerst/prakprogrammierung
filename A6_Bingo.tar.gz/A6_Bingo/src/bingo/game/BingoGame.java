/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bingo.game;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author ju39gox
 */
public class BingoGame
{
    public static final Random RANDOM = new Random();
    
    private ArrayList<BingoListener> listeners;    
    private BingoGameState gameState;
    private ArrayList<BingoCard> cards;
    private int currentRoundPlayerIndex;
    private int currentNumber;

    public BingoGame()
    {
        listeners = new ArrayList<>();

        gameState = BingoGameState.NOT_STARTED;
        cards = new ArrayList<>();
        currentRoundPlayerIndex = -1;        
    }

    public void startGame()
    {
        if (gameState != BingoGameState.NOT_STARTED)
        {
            throw new BingoGameException("Game already started!");
        }

        gameState = BingoGameState.RUNNING;

        dice();
    }

    private void dice()
    {
        currentRoundPlayerIndex = -1;
        currentNumber = RANDOM.nextInt(75) + 1;

        for (BingoListener listener : listeners)
        {
            listener.bingoDiced(currentNumber);
        }

        nextPlayer();
    }

    public void shoutBingo(BingoCard card)
    {
        if (card.hasBingo())
        {
            playerWon(card);
        }
    }

    private void playerWon(BingoCard winner)
    {
        for (BingoListener listener : listeners)
        {
            listener.bingoWon(winner);
        }

        gameState = BingoGameState.FINISHED;
    }

    public void nextPlayer()
    {
        currentRoundPlayerIndex++;

        if (currentRoundPlayerIndex >= cards.size())
        {
            dice();
        }
        else
        {
            BingoCard player = cards.get(currentRoundPlayerIndex);

            for (BingoListener listener : listeners)
            {
                listener.bingoPlayerTurn(player);
            }

            if (!player.isHuman())
            {
                player.markCurrentNumber();

                if (player.hasBingo())
                {
                    playerWon(player);
                    return;
                }

                nextPlayer();
            }
        }
    }

    public void addPlayer(String name, boolean isHuman)
    {
        if (gameState != BingoGameState.NOT_STARTED)
        {
            throw new RuntimeException("Game already started. Cannot add more players!");
        }

        if (getPlayer(name) != null)
        {
            throw new RuntimeException("Player already existing!");
        }

        cards.add(new BingoCard(name, isHuman, this));
    }

    public void addBingoListener(BingoListener listener)
    {
        listeners.add(listener);
    }

    public void removeBingoListener(BingoListener listener)
    {
        listeners.remove(listener);
    }

    public BingoCard getPlayer(String name)
    {
        for (BingoCard player : cards)
        {
            if (player.getName().equals(name))
            {
                return player;
            }
        }

        return null;
    }

    public ArrayList<BingoCard> getPlayers()
    {
        return (ArrayList<BingoCard>) cards.clone();
    }

    public int getCurrentNumber()
    {
        return currentNumber;
    }

    public BingoCard getCurrentPlayer()
    {
        if (currentRoundPlayerIndex < 0 || currentRoundPlayerIndex >= cards.size())
        {
            return null;
        }

        return cards.get(currentRoundPlayerIndex);
    }

    public BingoGameState getState()
    {
        return gameState;
    }
}
